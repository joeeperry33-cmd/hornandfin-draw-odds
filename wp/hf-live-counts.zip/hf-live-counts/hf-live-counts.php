<?php
/**
 * Plugin Name: Horn & Fin - live listing and review counts
 * Description: Keeps the listing and review numbers on the homepage up to date. Put %%hf_listings%% or %%hf_reviews%% in any Elementor widget, or use the [hf_listings] / [hf_reviews] shortcodes. Counts refresh when a listing or review changes, and at least every hour.
 * Version: 1.0
 * Author: Horn & Fin
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

const HF_LC_KEY = 'hf_live_counts_v1';

function hf_lc_tables() {
	global $wpdb;
	static $t = null;
	if ( null === $t ) {
		$t = array();
		foreach ( array( 'content', 'comments' ) as $n ) {
			$name = $wpdb->prefix . 'jreviews_' . $n;
			$t[ $n ] = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $name ) ) === $name ) ? $name : '';
		}
	}
	return $t;
}

/** Published listings = published posts that JReviews tracks as listings. */
function hf_lc_listings() {
	global $wpdb;
	$t = hf_lc_tables();
	if ( ! $t['content'] ) { return null; }
	return (int) $wpdb->get_var( "SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p INNER JOIN {$t['content']} c ON c.contentid = p.ID WHERE p.post_status = 'publish' AND p.post_type = 'post'" );
}

/** Published user reviews on published listings. */
function hf_lc_reviews() {
	global $wpdb;
	$t = hf_lc_tables();
	if ( ! $t['comments'] ) { return null; }
	return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['comments']} r INNER JOIN {$wpdb->posts} p ON p.ID = r.pid WHERE r.published = 1 AND p.post_status = 'publish'" );
}

function hf_lc_counts() {
	$c = get_transient( HF_LC_KEY );
	if ( ! is_array( $c ) ) {
		$c = array( 'listings' => hf_lc_listings(), 'reviews' => hf_lc_reviews() );
		set_transient( HF_LC_KEY, $c, HOUR_IN_SECONDS );
	}
	return $c;
}

function hf_lc_get( $which ) {
	$c = hf_lc_counts();
	$n = isset( $c[ $which ] ) ? $c[ $which ] : null;
	if ( null === $n ) {
		$n = (int) get_option( 'hf_lc_fallback_' . $which, 0 );
	} else {
		update_option( 'hf_lc_fallback_' . $which, $n, false );
	}
	return number_format_i18n( $n );
}

function hf_lc_replace( $html ) {
	if ( false === strpos( $html, '%%hf_' ) ) { return $html; }
	return str_replace(
		array( '%%hf_listings%%', '%%hf_reviews%%' ),
		array( hf_lc_get( 'listings' ), hf_lc_get( 'reviews' ) ),
		$html
	);
}
add_filter( 'elementor/widget/render_content', 'hf_lc_replace', 20 );
add_filter( 'elementor/frontend/the_content', 'hf_lc_replace', 20 );
add_filter( 'the_content', 'hf_lc_replace', 20 );

add_shortcode( 'hf_listings', function () { return hf_lc_get( 'listings' ); } );
add_shortcode( 'hf_reviews', function () { return hf_lc_get( 'reviews' ); } );

/** Refresh when listings change. */
function hf_lc_flush() { delete_transient( HF_LC_KEY ); }
add_action( 'transition_post_status', function ( $new, $old, $post ) {
	if ( $new !== $old && $post && 'post' === $post->post_type && ( 'publish' === $new || 'publish' === $old ) ) { hf_lc_flush(); }
}, 10, 3 );
add_action( 'deleted_post', 'hf_lc_flush' );
/** JReviews saves reviews over admin-ajax; refresh after any JReviews request that writes. */
add_action( 'shutdown', function () {
	if ( defined( 'DOING_AJAX' ) && DOING_AJAX && 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? '' ) && false !== stripos( (string) ( $_REQUEST['action'] ?? '' ), 'jreviews' ) ) { hf_lc_flush(); }
} );

/** Admin-only check: /wp-json/hf/v1/counts */
add_action( 'rest_api_init', function () {
	register_rest_route( 'hf/v1', '/counts', array(
		'methods'             => 'GET',
		'permission_callback' => function () { return current_user_can( 'manage_options' ); },
		'callback'            => function () {
			global $wpdb;
			hf_lc_flush();
			$t   = hf_lc_tables();
			$out = array( 'tables' => $t, 'counts' => hf_lc_counts() );
			$out['jreviews_tables'] = $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $wpdb->prefix . 'jreviews' ) . '%' ) );
			$out['published_posts'] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status='publish' AND post_type='post'" );
			if ( $t['comments'] ) {
				$out['reviews_all_rows']  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['comments']}" );
				$out['reviews_published'] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['comments']} WHERE published = 1" );
				$out['review_columns']    = $wpdb->get_col( "SHOW COLUMNS FROM {$t['comments']}" );
			}
			if ( $t['content'] ) {
				$out['content_rows'] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['content']}" );
			}
			return $out;
		},
	) );
} );
